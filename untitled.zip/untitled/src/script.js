// Wait for the DOM to fully load
document.addEventListener("DOMContentLoaded", function () {

    // Toggle Light Mode and High Contrast Mode
    const toggleThemeButton = document.getElementById('toggle-theme');
    if (toggleThemeButton) {
        toggleThemeButton.addEventListener('click', () => {
            document.body.classList.toggle('light-mode');
            document.body.classList.toggle('high-contrast');
            toggleThemeButton.setAttribute('aria-pressed', document.body.classList.contains('light-mode'));
        });
    }

    // Text-to-Speech
    const readContentButton = document.getElementById('read-content');
    if (readContentButton) {
        readContentButton.addEventListener('click', () => {
            const text = document.querySelector('.hero-text').textContent;
            const speech = new SpeechSynthesisUtterance(text);
            window.speechSynthesis.speak(speech);
        });
    }

    // Text Resizing Controls
    const increaseTextBtn = document.getElementById('increase-text');
    const decreaseTextBtn = document.getElementById('decrease-text');
    let fontSize = 100;

    if (increaseTextBtn) {
        increaseTextBtn.addEventListener('click', () => {
            fontSize += 10;
            document.body.style.fontSize = `${fontSize}%`;
        });
    }

    if (decreaseTextBtn) {
        decreaseTextBtn.addEventListener('click', () => {
            fontSize -= 10;
            document.body.style.fontSize = `${fontSize}%`;
        });
    }

    // Back to Top Button visibility on scroll
    window.onscroll = function() {
        const button = document.querySelector('.back-to-top');
        if (button) {
            if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
                button.style.display = 'block';
            } else {
                button.style.display = 'none';
            }
        }
    };

    // Back to Top Button functionality
    const backToTopButton = document.querySelector('.back-to-top');
    if (backToTopButton) {
        backToTopButton.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
});
